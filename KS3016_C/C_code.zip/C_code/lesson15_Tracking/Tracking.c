#include <wiringPi.h>
#include <stdio.h>
#define tracking 1  //tracking pin BCM GPIO 18
#define led 2  // led pin BCM GPIO 27

int main()
{
  wiringPiSetup();
  char val;
  {
    pinMode(tracking,INPUT);  //set the tracking pin INPUT mode
    pinMode(led,OUTPUT);
  }
  
  while(1)
  {
    val=digitalRead(tracking);  // digital read
    printf("val = %d\n", val);
    if(val==0)//check if the white line is pressed, if yes, turn on the Buzzer
      digitalWrite(led,HIGH);  //led on 
    else
      digitalWrite(led,LOW); // led off
  }	
}
