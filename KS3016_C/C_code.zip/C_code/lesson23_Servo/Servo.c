#include <wiringPi.h>
#define serPin 1 //servo pin BCM GPIO 18

int main()
{
	wiringPiSetup();
	pinMode(serPin,OUTPUT);
	int i;
	for(;;)
	{
		for(i=0;i<50;i++)            
		{
			digitalWrite(serPin,HIGH);
			delayMicroseconds(500); //Pulse width 0.5ms, Angle 0
			digitalWrite(serPin,LOW);
			delay(20-0.5);	//Cycle 20 ms
		}
		
		delay(1000);
		for(i=0;i<50;i++)         
		{
			digitalWrite(serPin,HIGH);
			delayMicroseconds(2500);
			digitalWrite(serPin,LOW);
			delay(20-2.5);
		}
        delay(1000);
	}
	return 0;
}
