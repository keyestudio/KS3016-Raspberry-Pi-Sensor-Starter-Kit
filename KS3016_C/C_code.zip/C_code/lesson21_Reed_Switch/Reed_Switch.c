#include <wiringPi.h>
#include <pcf8591.h>
#include <stdio.h>

#define reed_pin 1  //reed pin BCM GPIO 18
#define led_pin 21  //LED pin BCM GPIO 5

int main(void)
{
   int val = 0;
   wiringPiSetup();
   pinMode(reed_pin,INPUT);//set reed reedPin INPUT mode
   pinMode(led_pin,OUTPUT); //set ledPin OUTPUT mode
     
   while(1)
   {
      val=digitalRead(reed_pin);
      printf("val = %d\n",val);
      if(val==0) //when magnetism is detected
         digitalWrite(led_pin,HIGH);//led on
      else
         digitalWrite(led_pin,LOW);//led off
  }
}
