#include <wiringPi.h>
#include <pcf8591.h>
#include <stdio.h>

#define Hall_pin 1  //hall pin BCM GPIO 18
#define led_pin 21  //LED pin BCM GPIO 5

int main(void)
{
   int val = 0;
   wiringPiSetup();
   pinMode(Hall_pin,INPUT);
   pinMode(led_pin,OUTPUT);
     
   while(1)
   {
      val=digitalRead(Hall_pin);
      if(val==1)
      {
         printf("nonmagnetic\n");
         digitalWrite(led_pin,LOW);
      }
      else
      {
         printf("magnetic\n");
         digitalWrite(led_pin,HIGH);
      }
}
}
