#include <wiringPi.h>
#include <pcf8591.h>
#include <stdio.h>

#define Address 0x48  //address  ---> device address
#define BASE 64    //DA converter command
#define A0 BASE+0  //A0  ----> port address
#define A1 BASE+1
#define A2 BASE+2
#define A3 BASE+3


int main(void)
{
     unsigned char value;
     wiringPiSetup();
     pcf8591Setup(BASE,Address);  //which port of the device you want to access
        
     while(1)
     {
        value=analogRead(A0);              
        printf("A0:%d\n",value);
        delay(100);
       }
}
