#include <wiringPi.h>
#include <stdio.h>
#define photofracturePin 1  // photofracture Pin BCM GPIO 18
int main()
{
  wiringPiSetup();
  int val; //Photofracture variables
  int count = 0; //Record the number of photofracture
  int flag = 0;  //Odd even variable
  pinMode(photofracturePin,INPUT);
  
  while(1)
  { 
    val=digitalRead(photofracturePin);  //Receive photofracture value
    if(val == 0)
    {
      delay(10);
      val=digitalRead(photofracturePin);  //Receive photofracture value
      if(val == 1)
      {
        count = count + 1;
        printf("count = %d\n",count);
        delay(50);
      }
    }
    flag = count % 2; //Remainder 2 ,Even is 0, odd is 1
  }	 
}
