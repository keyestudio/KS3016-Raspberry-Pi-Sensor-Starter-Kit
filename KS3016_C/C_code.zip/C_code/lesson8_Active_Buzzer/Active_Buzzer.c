#include <wiringPi.h>
#include <stdio.h>
#define button 1   //button pin BCM GPIO 18
#define buzzer 27   //buzzer pin BCM GPIO 16
int main()
{
  wiringPiSetup();
  char val;
  {
    pinMode(button,INPUT);  //set the button pin INPUT mode
    pinMode(buzzer,OUTPUT);
  }
  
  while(1)
  {
    val=digitalRead(button);  // digital read
    printf("val = %d\n", val);
    if(val==0)//check if the button is pressed, if yes, turn on the Buzzer
      digitalWrite(buzzer,HIGH);  //The buzzer made a sound
    else
      digitalWrite(buzzer,LOW);
  }	
}
