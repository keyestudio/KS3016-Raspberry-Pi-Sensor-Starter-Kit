#include <wiringPi.h>
#include <stdio.h>
#define obstaclePin 1  //BCM GPIO 18
#define buzPin 2  //define buzzer pin  BCM GPIO 27
#define ledPin 21  //define led pin  BCM GPIO 5

int main()
{
  wiringPiSetup();
  char val;
  {
    pinMode(obstaclePin,INPUT);
    pinMode(buzPin,OUTPUT);
    pinMode(ledPin,OUTPUT);
    digitalWrite(buzPin,LOW);  
    digitalWrite(ledPin,LOW);
  }
  
  while(1)
  { 
   val=digitalRead(obstaclePin);
   printf("val = %d\n",val);
   if(val==0)  //When the obstacle avoidance is detected
   {
    digitalWrite(buzPin,HIGH);  //Buzzer turn on
    digitalWrite(ledPin,HIGH);  //LED turn on
    delay(100);
    digitalWrite(ledPin,LOW);  //LED turn off
    delay(100);
  }
   else
   {
    digitalWrite(buzPin,LOW);  //Buzzer turn off
    digitalWrite(ledPin,LOW);  //LED turn off
  }
  }	
}
