#include <wiringPi.h>
#include <stdio.h>
#define crash 1   //crash pin BCM GPIO 18
#define buzzer 27   //buzzer pin BCM GPIO 16
int main()
{
  wiringPiSetup();
  char val;
  {
    pinMode(crash,INPUT);  //set the crash pin INPUT mode
    pinMode(buzzer,OUTPUT);
  }
  
  while(1)
  {
    val=digitalRead(crash);  // digital read
    printf("val = %d\n", val);
    if(val==0)//check if the metal shrapnel is pressed, if yes, turn on the Buzzer
      digitalWrite(buzzer,HIGH);  //The buzzer made a sound
    else
      digitalWrite(buzzer,LOW);
  }	
}
