#include <wiringPi.h>
#include <stdio.h>
#define touchPin 1  //BCM GPIO 18
#define buzPin 2  //define buzzer pin  BCM GPIO 27

int main()
{
  wiringPiSetup();
  char val;
  {
    pinMode(touchPin,INPUT);
    pinMode(buzPin,OUTPUT);
  }
  
  while(1)
  { 
   val=digitalRead(touchPin);
   printf("val = %d\n",val);
   if(val==1) //When the touch area is touched
    digitalWrite(buzPin,HIGH);  //Buzzer turn on
   else
    digitalWrite(buzPin,LOW);  //Buzzer turn off
  }	
}
