#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wiringPi.h>
#include <pcf8591.h>


#define Address 0x48
#define BASE 64
#define A0 BASE+0
#define A1 BASE+1
#define A2 BASE+2
#define A3 BASE+3

#define buzPin 1   //buzzer pin  BCM GPIO 18

int main(void)
{
        unsigned char dat;
	wiringPiSetup();
        pcf8591Setup(BASE,Address);            
	if (wiringPiSetup() == -1){
	exit(1);
	}
	{
            pinMode(buzPin,OUTPUT);
	}
	while(1){
	    
	    dat=analogRead(A0); 
	    if(dat>80)
	        digitalWrite(buzPin,HIGH);
	    else
	        digitalWrite(buzPin,LOW);
            printf("MQ-3:%d\n",dat);
	    delay(100);
	}
   return 0;
}
