#include <wiringPi.h>
#include <stdio.h> //The stdio.h header file defines three variable types, 
                   //some macros, and various functions to perform input and output.

#define ledPin 1  //define led pin
int i1,i2,i3;

int main()
{
	wiringPiSetup();  //Initialize wiringPi

	pinMode(ledPin,OUTPUT);  //set the ledPin OUTPUT mode

	while(1)
	{
		while(i1<3)
		{
			digitalWrite(ledPin,HIGH);  //turn on led
			delay(100);       //delay 100ms
			digitalWrite(ledPin,LOW);   //turn off led
			delay(100);
			i1 = i1 + 1;
			printf(".\n");
		}
		while(i2<3)
		{
			digitalWrite(ledPin,HIGH);  //turn on led
			delay(1000);       //delay 1000ms      
			digitalWrite(ledPin,LOW);   //turn off led
			delay(1000);
			i2 = i2 + 1;
			printf("-\n");
		}
		while(i3<3)
		{
			digitalWrite(ledPin,HIGH);  //turn on led
			delay(100);       //delay 100ms      
			digitalWrite(ledPin,LOW);   //turn off led
			delay(100);
			i3 = i3 + 1;
			printf(".\n");
		}
		//clean
		i1 = 0;
		i2 = 0;
		i3 = 0;
		printf(" \n");
		delay(500);
	}
	
}
