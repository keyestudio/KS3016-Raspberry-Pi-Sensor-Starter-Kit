#include <wiringPi.h>
#include <stdio.h>
#include <pcf8591.h>
#include <math.h>

#define Address 0x48
#define BASE 64
#define A0 BASE+0
#define A1 BASE+1
#define A2 BASE+2
#define A3 BASE+3
 
int main(void){
    wiringPiSetup();
    pcf8591Setup(BASE,Address);
    
    while(1){
        int value = analogRead(A0);  //read analog value A0 pin    
        float voltage = (float)value / 255.0 * 5.0; // calculate voltage   
        float Rt = 4.7 * (5.0 / voltage) - 4.7 ; //calculate resistance value of thermistor, 5.0 * (R / (Rt + R)) = voltage,>>>Rt = R * (5.0 / voltage) - R
        float tempK = 1/(1/(273.15 + 25) + log(Rt/4.7)/3950.0);  //calculate temperature (Kelvin)
        float tempC = tempK - 273.15;  //calculate temperature (Celsius)
        printf("ADC value : %d  ,\tVoltage : %.2fV, \tTemperature : %.2fC\n",value,voltage,tempC);
        delay(100);
    }
    return(0);
}
