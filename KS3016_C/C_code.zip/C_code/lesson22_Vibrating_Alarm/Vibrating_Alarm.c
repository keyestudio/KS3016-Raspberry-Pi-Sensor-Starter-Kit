#include <wiringPi.h>
#include <stdio.h>

#define vibPin 1  //vibration pin BCM GPIO 18
#define buzPin 21   //buzzer pin BCM GPIO 5
int buz_status = 0;

void swbuz(void)
{
  buz_status = ~buz_status;
  digitalWrite(buzPin, buz_status);
  if(buz_status == 1)
  {
     printf("buzzer ring ...");
  }
  else
  {
     printf("...buzzer off");
  }
}

int main()
{
  wiringPiSetup();
  pinMode(buzPin, OUTPUT);
  pinMode(vibPin,INPUT);
  pullUpDnControl(vibPin, PUD_UP);
  wiringPiISR(vibPin,INT_EDGE_FALLING,swbuz); //interrupt
  
  while(1)
  { 
    //val=digitalRead(vibPin);  //Receive
    //printf("value = %d\n", val);
  }	 
}
