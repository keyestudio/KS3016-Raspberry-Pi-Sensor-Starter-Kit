#include <wiringPi.h>
#include <stdio.h>

#define relayPin 1  //BCM GPIO 18

int main()
{
  wiringPiSetup();
  pinMode(relayPin,OUTPUT);
  
  while(1)
  { 
        digitalWrite(relayPin,HIGH);
        printf("turn on\n");
        delay(5000);
        digitalWrite(relayPin,LOW);
        printf("turn off\n");
        delay(1000);  
  }	
}
