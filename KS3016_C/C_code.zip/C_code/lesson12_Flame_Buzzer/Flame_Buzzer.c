#include <wiringPi.h>
#include <stdio.h>
#define flamePin 1  //BCM GPIO 18
#define buzPin 27  //define buzzer pin  BCM GPIO 16

int main()
{
  wiringPiSetup();
  char val;
  {
    pinMode(flamePin,INPUT);
    pinMode(buzPin,OUTPUT);
  }
  
  while(1)
  { 
   val=digitalRead(flamePin);
   printf("val = %d\n",val);
   if(val==0) //When flame is detected
    digitalWrite(buzPin,HIGH);  //Buzzer turn on
   else
    digitalWrite(buzPin,LOW);  //Buzzer turn off
  }	
}
